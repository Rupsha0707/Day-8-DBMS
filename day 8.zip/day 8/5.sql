SELECT Name FROM Sports_Stud
UNION
SELECT Name FROM Cultural_Stud;